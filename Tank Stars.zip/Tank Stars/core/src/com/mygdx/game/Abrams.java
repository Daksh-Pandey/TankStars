package com.mygdx.game;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.Cell;

public class Abrams extends Actor {
    float x, y;
    Sprite sprite;
    private TiledMapTileLayer layer;

    Abrams(boolean reverse){

    }
}
